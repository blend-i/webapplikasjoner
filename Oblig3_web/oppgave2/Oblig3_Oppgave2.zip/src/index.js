import './main.scss';

const app = document.getElementById('mainjs');
app.innerHTML = '<h1>Hola</h1>';
console.log('test');
